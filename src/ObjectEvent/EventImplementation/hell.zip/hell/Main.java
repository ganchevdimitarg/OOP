package ObjectEvent.EventImplementation.hell;

import ObjectEvent.EventImplementation.hell.entities.miscellaneous.Commands.Commander;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String line = scanner.nextLine();

        while (!"Quit".equals(line)){

            Commander command = new Commander(line);
            command.commandsRunner();

            line = scanner.nextLine();
        }

    }
}