package ObjectEvent.EventImplementation.hell.entities.miscellaneous;

import ObjectEvent.EventImplementation.hell.interfaces.OutputWriter;

public class Writer implements OutputWriter {
    @Override
    public void writeLine(String output) {

    }

    @Override
    public void writeLine(String format, Object... params) {

    }
}
