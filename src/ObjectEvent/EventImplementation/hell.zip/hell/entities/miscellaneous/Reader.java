package ObjectEvent.EventImplementation.hell.entities.miscellaneous;

import ObjectEvent.EventImplementation.hell.interfaces.InputReader;

public class Reader implements InputReader {


    @Override
    public String readLine() {
        return null;
    }
}
