package ObjectEvent.EventImplementation.hell.entities.miscellaneous.Commands;

public class Inspect {
    private String name;

    public Inspect(String name) {
        this.name = name;
    }

    public void getInformation(){
        
    }
}
