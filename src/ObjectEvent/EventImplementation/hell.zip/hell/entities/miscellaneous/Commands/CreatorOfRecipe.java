package ObjectEvent.EventImplementation.hell.entities.miscellaneous.Commands;

import ObjectEvent.EventImplementation.hell.entities.miscellaneous.HeroInventory;
import ObjectEvent.EventImplementation.hell.entities.miscellaneous.Items.RecipeItem;
import ObjectEvent.EventImplementation.hell.interfaces.Recipe;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CreatorOfRecipe {
    public void createRecipe(String[] token) {
        String nameOfItem = token[1];
        String heroName = token[2];
        int strengthBonus = Integer.parseInt(token[3]);
        int agilityBonus = Integer.parseInt(token[4]);
        int intelligenceBonus = Integer.parseInt(token[5]);
        int hitpointsBonus = Integer.parseInt(token[6]);
        int damageBonus = Integer.parseInt(token[7]);
        List<String> items = Arrays.stream(token).skip(8).collect(Collectors.toList());

        Recipe recipe = new RecipeItem(nameOfItem, strengthBonus, agilityBonus, intelligenceBonus, hitpointsBonus,
                damageBonus, items);
        HeroInventory inventory = new HeroInventory();
        inventory.addRecipeItem(recipe);
        printerRecipe(heroName, recipe);
    }

    private void printerRecipe(String heroName, Recipe recipe) {
        System.out.printf("A Added recipe - %s to Hero - %s%n", recipe.getName(), heroName);
    }
}
