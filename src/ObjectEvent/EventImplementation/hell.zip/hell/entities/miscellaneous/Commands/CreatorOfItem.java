package ObjectEvent.EventImplementation.hell.entities.miscellaneous.Commands;

import ObjectEvent.EventImplementation.hell.entities.miscellaneous.HeroInventory;
import ObjectEvent.EventImplementation.hell.entities.miscellaneous.Items.CommonItem;
import ObjectEvent.EventImplementation.hell.interfaces.Item;

public class CreatorOfItem {

    public void createItem(String[] token) {
       String nameOfItem = token[1];
       String heroName = token[2];
       int strengthBonus = Integer.parseInt(token[3]);
       int agilityBonus = Integer.parseInt(token[4]);
       int intelligenceBonus = Integer.parseInt(token[5]);
       int hitpointsBonus = Integer.parseInt(token[6]);
       int damageBonus = Integer.parseInt(token[7]);
        Item item = new CommonItem(nameOfItem, strengthBonus, agilityBonus, intelligenceBonus,
                hitpointsBonus, damageBonus);
        HeroInventory inventory = new HeroInventory();
        inventory.addCommonItem(item);
        printerItemOwner(heroName, item);
    }

    private void printerItemOwner(String heroName, Item item) {
        System.out.printf("Added item - %s to Hero - %s%n", item.getName(), heroName);
    }
}
