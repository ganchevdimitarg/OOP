package ObjectEvent.EventImplementation.hell.entities.miscellaneous;

import java.util.List;

public class Manager implements ObjectEvent.EventImplementation.hell.interfaces.Manager {
    @Override
    public String addHero(List<String> arguments) {
        return null;
    }

    @Override
    public String addItem(List<String> arguments) {
        return null;
    }

    @Override
    public String addRecipe(List<String> arguments) {
        return null;
    }

    @Override
    public String inspect(List<String> arguments) {
        return null;
    }

    @Override
    public String quit() {
        return null;
    }
}
