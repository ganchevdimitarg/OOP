package ObjectEvent.EventImplementation.hell.entities.miscellaneous.Heros;

import ObjectEvent.EventImplementation.hell.interfaces.Item;
import ObjectEvent.EventImplementation.hell.interfaces.Recipe;

public class Barbarian extends Heroes {
    public Barbarian(String name) {
        super(name, 90, 25, 10, 350, 150);
    }

    @Override
    public void addItem(Item item) {

    }

    @Override
    public void addRecipe(Recipe recipe) {

    }
}
