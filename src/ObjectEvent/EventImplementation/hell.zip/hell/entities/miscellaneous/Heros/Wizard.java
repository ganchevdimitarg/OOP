package ObjectEvent.EventImplementation.hell.entities.miscellaneous.Heros;

import ObjectEvent.EventImplementation.hell.interfaces.Item;
import ObjectEvent.EventImplementation.hell.interfaces.Recipe;

public class Wizard extends Heroes {
    public Wizard(String name) {
        super(name, 25, 25, 100, 100, 250);
    }

    @Override
    public void addItem(Item item) {

    }

    @Override
    public void addRecipe(Recipe recipe) {

    }
}
