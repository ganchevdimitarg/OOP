package ObjectEvent.EventImplementation.hell.entities.miscellaneous.Heros;

import ObjectEvent.EventImplementation.hell.interfaces.Item;
import ObjectEvent.EventImplementation.hell.interfaces.Recipe;

public class Assassin extends Heroes {
    public Assassin(String name) {
        super(name, 25, 100, 15, 150, 300);
    }

    @Override
    public void addItem(Item item) {

    }

    @Override
    public void addRecipe(Recipe recipe) {

    }
}
