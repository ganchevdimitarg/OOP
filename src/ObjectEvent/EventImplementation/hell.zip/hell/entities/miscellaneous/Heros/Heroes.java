package ObjectEvent.EventImplementation.hell.entities.miscellaneous.Heros;

import ObjectEvent.EventImplementation.hell.interfaces.Hero;
import ObjectEvent.EventImplementation.hell.interfaces.Item;

import java.util.ArrayList;
import java.util.List;

public abstract class Heroes implements Hero {
    private String name;
    private long strength;
    private long agility;
    private long intelligence;
    private long hitPoints;
    private long damage;
    private List<Item> items;

    public Heroes(String name, int strength, int agility, int intelligence, int hitPoints, int damage) {
        this.name = name;
        this.strength = strength;
        this.agility = agility;
        this.intelligence = intelligence;
        this.hitPoints = hitPoints;
        this.damage = damage;
        this.items = new ArrayList<>();
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public long getStrength() {
        return strength;
    }

    @Override
    public long getAgility() {
        return agility;
    }

    @Override
    public long getIntelligence() {
        return intelligence;
    }

    @Override
    public long getHitPoints() {
        return hitPoints;
    }

    @Override
    public long getDamage() {
        return damage;
    }

    @Override
    public List<Item> getItems() {
        return items;
    }

}
