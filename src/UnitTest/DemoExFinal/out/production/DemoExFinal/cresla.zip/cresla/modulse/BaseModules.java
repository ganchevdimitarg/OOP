package cresla.modulse;

import cresla.interfaces.Module;

public abstract class BaseModules implements Module {
    private int id;

    protected BaseModules(int id) {
        this.id = id;
    }

    @Override
    public int getId() {
        return this.id;
    }
}
