package cresla.entities.containers.Module;

public class HeatProcessor extends Heater {

    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
