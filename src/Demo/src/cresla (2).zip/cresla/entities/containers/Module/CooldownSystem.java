package cresla.entities.containers.Module;


public class CooldownSystem extends Heater {

    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
