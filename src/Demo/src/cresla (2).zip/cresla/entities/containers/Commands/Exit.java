package cresla.entities.containers.Commands;

public class Exit {
}
