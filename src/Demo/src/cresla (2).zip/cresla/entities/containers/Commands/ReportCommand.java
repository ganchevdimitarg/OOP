package cresla.entities.containers.Commands;

public class ReportCommand {
    private int id;

    public String printAllInfo(int id){

        return String.format(" ");
    }

}
