package cresla.Commands;

public class Exit {
}
