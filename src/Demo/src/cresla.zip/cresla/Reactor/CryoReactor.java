package cresla.Reactor;

import cresla.entities.containers.ModuleContainer;
import cresla.interfaces.AbsorbingModule;
import cresla.interfaces.EnergyModule;

public class CryoReactor extends Reactors {

   private int cryoProductionIndex;

    public CryoReactor(ModuleContainer moduleContainer, int cryoProductionIndex) {
        super(moduleContainer);
        this.cryoProductionIndex = cryoProductionIndex;
    }

    public int getCryoProductionIndex() {
        return cryoProductionIndex;
    }

    @Override
    public long getTotalEnergyOutput() {
        return 0;
    }

    @Override
    public long getTotalHeatAbsorbing() {
        return 0;
    }

    @Override
    public int getModuleCount() {
        return 0;
    }

    @Override
    public void addEnergyModule(EnergyModule energyModule) {

    }

    @Override
    public void addAbsorbingModule(AbsorbingModule absorbingModule) {

    }

    @Override
    public int getId() {
        return 0;
    }
}
