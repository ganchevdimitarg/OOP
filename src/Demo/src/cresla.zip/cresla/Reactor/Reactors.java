package cresla.Reactor;

import cresla.entities.containers.ModuleContainer;
import cresla.interfaces.Reactor;

public abstract class Reactors implements Reactor {
    private static int DEFAULT_ID = 0;
    private int id;
    private ModuleContainer moduleContainer;

    protected Reactors(ModuleContainer moduleContainer) {
        this.id = DEFAULT_ID + 1;
        this.moduleContainer = moduleContainer;
        DEFAULT_ID++;
    }
}
