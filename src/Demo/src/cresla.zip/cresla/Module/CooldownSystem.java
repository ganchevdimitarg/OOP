package cresla.Module;


public class CooldownSystem extends Heater {

    public CooldownSystem(int heatAbsorbing) {
        super(heatAbsorbing);
    }
}
