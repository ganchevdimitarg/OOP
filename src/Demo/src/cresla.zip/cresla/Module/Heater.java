package cresla.Module;

import cresla.interfaces.AbsorbingModule;

public class Heater extends Modules implements AbsorbingModule {
    private static long TOTAL_ABSORB = 0;
    private int heatAbsorbing;

    public Heater(int heatAbsorbing) {
        this.heatAbsorbing = heatAbsorbing;
        TOTAL_ABSORB += heatAbsorbing;
    }


    @Override
    public int getHeatAbsorbing() {
        return this.heatAbsorbing;
    }

    @Override
    public long getTotalHeatAbsorbing() {
        return TOTAL_ABSORB;
    }
}
