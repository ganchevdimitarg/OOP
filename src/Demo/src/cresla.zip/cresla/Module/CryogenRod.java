package cresla.Module;

import cresla.interfaces.EnergyModule;

public class CryogenRod extends Modules implements EnergyModule {
    private static long TOTAL_ENERGY = 0;
    private int energyOutput;

    public CryogenRod(int energyOutput) {

        this.energyOutput = energyOutput;
        TOTAL_ENERGY += energyOutput;
    }


    @Override
    public int getEnergyOutput() {
        return this.energyOutput;
    }


    @Override
    public long getTotalEnergyOutput() {
        return TOTAL_ENERGY;
    }
}
