package cresla.Module;

import cresla.Reactor.Reactors;
import cresla.interfaces.Module;

public abstract class Modules extends Reactors implements Module {
    private static int DEFAULT_ID = 0;
    private int id;

    protected Modules() {
        super();
        this.id = DEFAULT_ID + 1;
        DEFAULT_ID++;
    }
    @Override
    public long getTotalEnergyOutput() {
        return 0;
    }

    @Override
    public long getTotalHeatAbsorbing() {
        return 0;
    }

    @Override
    public int getId() {
        return this.id;
    }
}
