package cresla.Module;

public class HeatProcessor extends Heater {

    public HeatProcessor(int heatAbsorbing) {
        super(heatAbsorbing);
    }
}
