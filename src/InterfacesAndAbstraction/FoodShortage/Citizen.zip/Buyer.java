
public interface Buyer {
    void buyFood();
    int getFood();
}
