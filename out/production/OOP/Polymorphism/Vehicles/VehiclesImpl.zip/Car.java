package Vehicles;
import java.text.DecimalFormat;

public class Car extends VehiclesImpl {

    private double liters;

    public Car(double fuelQuantity, double fuelConsumption) {
        super(fuelQuantity, fuelConsumption);
    }

    protected boolean driving(double distance) {
        double leftFuel = this.getFuelQuantity() - ((this.getFuelConsumption() + 0.9) * distance);
        if (leftFuel >= 0) {
            this.setFuelQuantity(leftFuel);
            return true;
        }
        return false;
    }

    @Override
    public void refueled(double liters) {
        this.liters = liters;
        this.setFuelQuantity(this.getFuelQuantity() + liters);
    }

    @Override
    public void printVehicleTravelled(double distance){
        DecimalFormat format = new DecimalFormat("####.##");
        if (driving(distance)){
            System.out.println("Car travelled " + format.format(distance) + " km");
        } else {
            System.out.println("Car needs refueling");
        }
    }

    @Override
    public void printVehicleLeftFuel(){
        System.out.printf("Car: %.2f%n", this.getFuelQuantity());
    }
}
