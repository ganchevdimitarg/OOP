package Vehicles;

public abstract class VehiclesImpl implements Vehicles {
    private double fuelQuantity;
    private double fuelConsumption;

    public VehiclesImpl(double fuelQuantity, double fuelConsumption) {
        this.fuelQuantity = fuelQuantity;
        this.fuelConsumption = fuelConsumption;
    }

    protected void setFuelQuantity(double fuelQuantity) {
        this.fuelQuantity = fuelQuantity;
    }

    protected double getFuelQuantity() {
        return this.fuelQuantity;
    }

    protected double getFuelConsumption() {
        return this.fuelConsumption;
    }

    protected abstract boolean driving(double distance);


}
