package Vehicles;

public interface Vehicles {

    void refueled(double liters);

    void printVehicleTravelled(double distance);

    void printVehicleLeftFuel();
}
