package Vehicles;

import java.text.DecimalFormat;

public class Truck extends VehiclesImpl {
    public Truck(double fuelQuantity, double fuelConsumption) {
        super(fuelQuantity, fuelConsumption);
    }

    protected boolean driving(double distance) {
        double leftFuel = this.getFuelQuantity() - ((this.getFuelConsumption() + 1.6) * distance);
        if (leftFuel >= 0) {
            this.setFuelQuantity(leftFuel);
            return true;
        }
        return false;
    }

    @Override
    public void refueled(double liters) {
        this.setFuelQuantity(this.getFuelQuantity() + (liters * 0.95));
    }

    @Override
    public void printVehicleTravelled(double distance) {
        DecimalFormat format = new DecimalFormat("####.##");
        if (driving(distance)) {
            System.out.println("Truck travelled " + format.format(distance) + " km");
        } else {
            System.out.println("Truck needs refueling");
        }
    }

    @Override
    public void printVehicleLeftFuel(){
        System.out.printf("Truck: %.2f%n", this.getFuelQuantity());
    }
}
