package Vehicles;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[] carInfo = reader.readLine().split("\\s+");
        String[] truckInfo = reader.readLine().split("\\s+");
        int commands = Integer.parseInt(reader.readLine());

        Car car = new Car(Double.parseDouble(carInfo[1]), Double.parseDouble(carInfo[2]));
        Truck truck = new Truck(Double.parseDouble(truckInfo[1]), Double.parseDouble(truckInfo[2]));

        while (commands-- > 0) {
            String[] commandInfo = reader.readLine().split("\\s+");
            if (commandInfo[0].equals("Drive")) {
                if (commandInfo[1].equals("Car")) {
                    car.printVehicleTravelled(Double.parseDouble(commandInfo[2]));
                } else {
                    truck.printVehicleTravelled(Double.parseDouble(commandInfo[2]));
                }
            } else {
                if (commandInfo[1].equals("Car")) {
                    car.refueled(Double.parseDouble(commandInfo[2]));
                } else {
                    truck.refueled(Double.parseDouble(commandInfo[2]));
                }
            }
        }
        car.printVehicleLeftFuel();
        truck.printVehicleLeftFuel();
    }
}
