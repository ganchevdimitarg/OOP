package hell.entities.miscellaneous;

import hell.interfaces.InputReader;

public class Reader implements InputReader {


    @Override
    public String readLine() {
        return null;
    }
}
