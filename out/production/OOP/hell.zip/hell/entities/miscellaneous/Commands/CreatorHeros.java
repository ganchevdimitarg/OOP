package hell.entities.miscellaneous.Commands;

import hell.entities.miscellaneous.Heros.Assassin;
import hell.entities.miscellaneous.Heros.Barbarian;
import hell.entities.miscellaneous.Heros.Heroes;
import hell.entities.miscellaneous.Heros.Wizard;

public class CreatorHeros {
    public void createHero(String[] token) {
        switch (token[2]) {
            case "Barbarian":
                Barbarian barbarian = new Barbarian(token[1]);
                printerHero(barbarian);
                break;
            case "Assassin":
                Assassin assassin = new Assassin(token[1]);
                printerHero(assassin);
                break;
            case "Wizard":
                Wizard wizard = new Wizard(token[1]);
                printerHero(wizard);
                break;
        }
    }

    private void printerHero(Heroes hero){
        System.out.printf("Created %s - %s%n", hero.getClass().getSimpleName(),hero.getName());
    }
}
