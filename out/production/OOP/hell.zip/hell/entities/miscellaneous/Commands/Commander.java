package  hell.entities.miscellaneous.Commands;

public class Commander {
    private String lines;

    public Commander(String lines) {
        this.lines = lines;
    }

    public void commandsRunner() {
        String[] token = this.lines.split("\\s+");

        switch (token[0]) {
            case "Hero":
                CreatorHeros hero = new CreatorHeros();
                hero.createHero(token);
                break;
            case "Item":
                CreatorOfItem item = new CreatorOfItem();
                item.createItem(token);
                break;
            case "Recipe":
//                CreatorOfRecipe recipe = new CreatorOfRecipe();
//                recipe.createRecipe(token);
                break;
            case "Inspect":

                break;
            case "Quit":

                break;
        }
    }
}
