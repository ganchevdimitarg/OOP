package hell.entities.miscellaneous.Commands;

import hell.interfaces.Recipe;

import java.util.List;

public class CreatorOfRecipe implements Recipe {
    private String nameOfItem;
    private String heroName;
    private int strengthBonus;
    private int agilityBonus;
    private int intelligenceBonus;
    private int hitpointsBonus;
    private int damageBonus;
    private List<String> items;

    public CreatorOfRecipe(String nameOfItem, String heroName, int strengthBonus, int agilityBonus, int intelligenceBonus, int hitpointsBonus, int damageBonus, List<String> items) {
        this.nameOfItem = nameOfItem;
        this.heroName = heroName;
        this.strengthBonus = strengthBonus;
        this.agilityBonus = agilityBonus;
        this.intelligenceBonus = intelligenceBonus;
        this.hitpointsBonus = hitpointsBonus;
        this.damageBonus = damageBonus;
        this.items = items;
    }

    public void createRecipe() {
//        Recipe recipe = new RecipeItem(this.getName(), this.getStrengthBonus(), this.getAgilityBonus(),
//                this.getIntelligenceBonus(), this.getHitPointsBonus(),this.getDamageBonus(), this.getRequiredItems());
//        HeroInventory inventory = new HeroInventory();
//        inventory.addRecipeItem(recipe);
//        printerRecipe(heroName, recipe);
    }

    private void printerRecipe(String heroName, Recipe recipe) {
        System.out.printf("A Added recipe - %s to Hero - %s%n", recipe.getName(), heroName);
    }


    @Override
    public List<String> getRequiredItems() {
        return this.items;
    }

    @Override
    public String getName() {
        return this.heroName;
    }

    @Override
    public int getStrengthBonus() {
        return this.strengthBonus;
    }

    @Override
    public int getAgilityBonus() {
        return this.agilityBonus;
    }

    @Override
    public int getIntelligenceBonus() {
        return this.intelligenceBonus;
    }

    @Override
    public int getHitPointsBonus() {
        return this.hitpointsBonus;
    }

    @Override
    public int getDamageBonus() {
        return this.damageBonus;
    }
}
