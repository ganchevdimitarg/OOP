package hell.entities.miscellaneous;

import hell.interfaces.OutputWriter;

public class Writer implements OutputWriter {
    @Override
    public void writeLine(String output) {

    }

    @Override
    public void writeLine(String format, Object... params) {

    }
}
