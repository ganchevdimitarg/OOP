package hell.entities.miscellaneous.Items;

import java.util.List;

public class RecipeItem extends Items{
    private List<CommonItem> requiredItems;

    public RecipeItem(String name, int strengthBonus, int agilityBonus, int intelligenceBonus, int hitPointsBonus, int damageBonus, List<CommonItem> requiredItems) {
        super(name, strengthBonus, agilityBonus, intelligenceBonus, hitPointsBonus, damageBonus);
        this.requiredItems = requiredItems;
    }

    public List<CommonItem> getRequiredItems() {
        return requiredItems;
    }
}
